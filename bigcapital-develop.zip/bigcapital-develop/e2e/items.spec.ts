import { test, expect, Page } from '@playwright/test';

test.describe('item', () => {
  test('should validate all required fields.', () => {});
  test('should save the item successfully.', () => {});
  test('should item code be unqiue.', () => {});
});
