// Default load extensions.
export const DEFAULT_LOAD_EXTENSIONS = [
  '.co',
  '.coffee',
  '.eg',
  '.iced',
  '.js',
  '.cjs',
  '.litcoffee',
  '.ls',
  '.ts',
];
