
export class Seeder {
  knex: any;

  constructor(knex) {
    this.knex = knex;
  }
  up(knex) {}
  down(knex) {}
}

