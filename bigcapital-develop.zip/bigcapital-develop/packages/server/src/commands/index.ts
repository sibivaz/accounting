import commander from 'commander';
import './bigcapital';

commander.parse();
