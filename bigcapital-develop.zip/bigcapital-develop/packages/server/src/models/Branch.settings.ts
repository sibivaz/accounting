export default {
  fields2: {
    name: {
      name: 'Name',
      fieldType: 'text',
      required: true,
    },
  },
  columns: {},
  fields: {}
};
