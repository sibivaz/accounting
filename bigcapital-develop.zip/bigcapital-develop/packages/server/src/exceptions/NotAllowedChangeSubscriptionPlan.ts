

export default class NotAllowedChangeSubscriptionPlan {

  constructor() {
    this.name = "NotAllowedChangeSubscriptionPlan";
  }
}