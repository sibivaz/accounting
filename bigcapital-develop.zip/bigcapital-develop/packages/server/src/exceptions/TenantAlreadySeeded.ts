export default class TenantAlreadySeeded {
  constructor() {}
}
