



export default class TenantDBAlreadyExists {
  constructor() {
    
  }
}