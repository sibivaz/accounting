export default class TenantDatabaseNotBuilt {
  constructor() {}
}
