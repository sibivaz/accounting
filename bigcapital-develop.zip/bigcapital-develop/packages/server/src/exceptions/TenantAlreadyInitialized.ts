export default class TenantAlreadyInitialized {
  constructor() {}
}
