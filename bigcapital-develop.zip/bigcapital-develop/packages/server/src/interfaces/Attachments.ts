export interface AttachmentLinkDTO {
  key: string;
}
