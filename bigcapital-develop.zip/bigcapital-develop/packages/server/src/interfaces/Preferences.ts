


export enum PreferencesAction {
  Mutate = 'Mutate'
}