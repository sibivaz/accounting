
npm install
npm run build
npm run copy-i18n